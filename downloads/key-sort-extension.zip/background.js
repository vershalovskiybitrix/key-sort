"use strict";

const SITE = "https://key-sort.vershalovskiy.com/";
const WORDSTAT_URL = "https://searchapi.api.cloud.yandex.net/v2/wordstat/topRequests";
const WORDSTAT_REGIONS_URL = "https://searchapi.api.cloud.yandex.net/v2/wordstat/getRegionsTree";
const DIRECT_URL = "https://api.direct.yandex.ru/live/v4/json/";
const DIRECT_DICTIONARIES_URL = "https://api.direct.yandex.ru/json/v5/dictionaries";
const ALLOWED_DIRECT_METHODS = new Set(["CreateNewForecast", "GetForecastList", "GetForecast", "DeleteForecastReport"]);
const WORDSTAT_DEFAULT_DAILY_LIMIT = 500;
const WORDSTAT_MAX_DAILY_LIMIT = 5000;
const FORECAST_DEFAULTS = { hourly: 30, daily: 100, autoResume: true };
const FORECAST_MAXIMUMS = { hourly: 300, daily: 1000 };
const FORECAST_LOCK_TTL = 2 * 60 * 1000;
const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
let wordstatReservationChain = Promise.resolve();

function pageRequest(sender) {
  return Boolean(sender.tab?.url?.startsWith(SITE));
}

async function settings() {
  return chrome.storage.local.get(["cloudApiKey", "folderId", "directOAuthToken", "wordstatDailyLimit", "forecastHourlyLimit", "forecastDailyLimit", "forecastAutoResume"]);
}

function wordstatDailyLimit(value) {
  const parsed = Number(value);
  return Number.isInteger(parsed) ? Math.max(1, Math.min(WORDSTAT_MAX_DAILY_LIMIT, parsed)) : WORDSTAT_DEFAULT_DAILY_LIMIT;
}

function reserveWordstatSlot() {
  const reservation = wordstatReservationChain.then(async () => {
    const now = Date.now();
    const stored = await chrome.storage.local.get(["wordstatTimestamps", "wordstatDailyLimit"]);
    const limit = wordstatDailyLimit(stored.wordstatDailyLimit);
    const timestamps = (stored.wordstatTimestamps || []).filter(timestamp => timestamp > now - DAY).sort((a, b) => a - b);
    if (timestamps.length >= limit) {
      const error = new Error("Превышен суточный лимит запросов Wordstat. Загляните в настройки расширения.");
      error.code = "WORDSTAT_DAILY_LIMIT";
      error.retryAfter = timestamps[0] + DAY - now;
      throw error;
    }
    timestamps.push(now);
    await chrome.storage.local.set({ wordstatTimestamps: timestamps });
  });
  wordstatReservationChain = reservation.catch(() => {});
  return reservation;
}

function forecastSettings(config) {
  const integer = (value, fallback, maximum) => {
    const parsed = Number(value);
    return Number.isInteger(parsed) ? Math.max(1, Math.min(maximum, parsed)) : fallback;
  };
  return {
    hourly: integer(config.forecastHourlyLimit, FORECAST_DEFAULTS.hourly, FORECAST_MAXIMUMS.hourly),
    daily: integer(config.forecastDailyLimit, FORECAST_DEFAULTS.daily, FORECAST_MAXIMUMS.daily),
    autoResume: config.forecastAutoResume !== false
  };
}

async function beginForecast() {
  const now = Date.now();
  const { directForecastLock } = await chrome.storage.local.get("directForecastLock");
  if (directForecastLock?.expiresAt > now) {
    const error = new Error("Другой расчёт прогноза уже выполняется");
    error.code = "FORECAST_SESSION_BUSY";
    error.retryAfter = directForecastLock.expiresAt - now;
    throw error;
  }
  const lock = { id: crypto.randomUUID(), expiresAt: now + FORECAST_LOCK_TTL, forecastIds: [] };
  await chrome.storage.local.set({ directForecastLock: lock });
  return { sessionId: lock.id };
}

async function forecastLock(sessionId, refresh = true) {
  const { directForecastLock } = await chrome.storage.local.get("directForecastLock");
  if (!sessionId || directForecastLock?.id !== sessionId || directForecastLock.expiresAt <= Date.now()) {
    throw new Error("Сеанс расчёта завершён. Запустите расчёт заново");
  }
  if (refresh) {
    directForecastLock.expiresAt = Date.now() + FORECAST_LOCK_TTL;
    await chrome.storage.local.set({ directForecastLock });
  }
  return directForecastLock;
}

async function endForecast(sessionId) {
  const { directForecastLock } = await chrome.storage.local.get("directForecastLock");
  if (directForecastLock?.id === sessionId) await chrome.storage.local.remove("directForecastLock");
  return true;
}

async function reserveForecastSlot() {
  const now = Date.now();
  const stored = await chrome.storage.local.get(["directForecastTimestamps", "forecastHourlyLimit", "forecastDailyLimit"]);
  const limits = forecastSettings(stored);
  const timestamps = (stored.directForecastTimestamps || []).filter(timestamp => timestamp > now - DAY).sort((a, b) => a - b);
  const hourly = timestamps.filter(timestamp => timestamp > now - HOUR);
  const retryAt = Math.max(
    hourly.length >= limits.hourly ? hourly[0] + HOUR : 0,
    timestamps.length >= limits.daily ? timestamps[0] + DAY : 0
  );
  if (retryAt > now) {
    const error = new Error("Достигнут лимит прогнозов. Расчёт продолжится автоматически");
    error.code = "FORECAST_RATE_LIMIT";
    error.retryAfter = retryAt - now;
    throw error;
  }
  return timestamps;
}

async function parseResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.error_str || `HTTP ${response.status}`);
  if (data.error_code || data.error) throw new Error(data.error_str || data.error?.error_string || data.error?.message || `Ошибка API ${data.error_code}`);
  return data;
}

async function wordstat(payload) {
  const config = await settings();
  if (!config.cloudApiKey || !config.folderId) throw new Error("Заполните API-ключ Yandex Cloud и ID каталога в настройках расширения");
  const phrase = String(payload.phrase || "").trim();
  if (!phrase) throw new Error("Пустой запрос");
  const numPhrases = Math.max(1, Math.min(2000, Number(payload.numPhrases) || 2000));
  const body = { phrase, numPhrases, folderId: config.folderId };
  if (Array.isArray(payload.regions) && payload.regions.length) body.regions = payload.regions.map(String).slice(0, 50);
  await reserveWordstatSlot();
  const response = await fetch(WORDSTAT_URL, {
    method: "POST",
    headers: { "Authorization": `Api-Key ${config.cloudApiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return parseResponse(response);
}

async function wordstatRegions() {
  const config = await settings();
  if (!config.cloudApiKey || !config.folderId) throw new Error("Заполните API-ключ Yandex Cloud и ID каталога в настройках расширения");
  const response = await fetch(WORDSTAT_REGIONS_URL, {
    method: "POST",
    headers: { "Authorization": `Api-Key ${config.cloudApiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ folderId: config.folderId })
  });
  return parseResponse(response);
}

async function directRegions() {
  const config = await settings();
  if (!config.directOAuthToken) throw new Error("Заполните OAuth-токен Директа в настройках расширения");
  const response = await fetch(DIRECT_DICTIONARIES_URL, {
    method: "POST",
    headers: { "Authorization": `Bearer ${config.directOAuthToken}`, "Accept-Language": "ru", "Content-Type": "application/json" },
    body: JSON.stringify({ method: "get", params: { DictionaryNames: ["GeoRegions"] } })
  });
  const data = await parseResponse(response);
  const items = data.result?.GeoRegions || [];
  return {
    regions: items.map(item => ({
      id: item.GeoRegionId,
      name: item.GeoRegionName,
      parentId: item.ParentId,
      type: item.GeoRegionType
    }))
  };
}

async function direct(payload) {
  const config = await settings();
  if (!config.directOAuthToken) throw new Error("Заполните OAuth-токен Директа в настройках расширения");
  if (!ALLOWED_DIRECT_METHODS.has(payload.method)) throw new Error("Метод Директа не разрешён расширением");
  const lock = await forecastLock(payload.sessionId);
  const batchKey = /^[a-f0-9-]{36}$/i.test(payload.batchId || "") ? `directForecastBatch:${payload.batchId}` : null;
  const batch = batchKey ? (await chrome.storage.local.get(batchKey))[batchKey] : null;
  if (batchKey && payload.method === "CreateNewForecast" && batch) {
    if (batch.id && !batch.deleted) return { data: batch.id };
    throw new Error("Статус создания прошлого прогноза неизвестен. Проверьте отчёт в Директе перед новым запуском.");
  }
  if (batch?.deleted && payload.method === "DeleteForecastReport" && batch.id === Number(payload.param)) return { data: true };
  const forecastTimestamps = payload.method === "CreateNewForecast" ? await reserveForecastSlot() : null;
  if (["GetForecast", "DeleteForecastReport"].includes(payload.method) && !lock.forecastIds.includes(Number(payload.param)) && batch?.id !== Number(payload.param)) {
    throw new Error("Расширение не создавало этот прогноз");
  }
  const request = { method: payload.method, locale: "ru", token: config.directOAuthToken };
  if (Object.prototype.hasOwnProperty.call(payload, "param")) request.param = payload.param;
  if (batchKey && payload.method === "CreateNewForecast") await chrome.storage.local.set({ [batchKey]: { pending: true } });
  const response = await fetch(DIRECT_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(request) });
  const data = await parseResponse(response);
  if (payload.method === "CreateNewForecast") {
    if (batchKey) await chrome.storage.local.set({ [batchKey]: { id: Number(data.data) } });
    forecastTimestamps.push(Date.now());
    await chrome.storage.local.set({ directForecastTimestamps: forecastTimestamps });
    lock.forecastIds.push(Number(data.data));
    lock.expiresAt = Date.now() + FORECAST_LOCK_TTL;
    await chrome.storage.local.set({ directForecastLock: lock });
  } else if (payload.method === "GetForecastList") {
    data.data = (data.data || []).filter(report => lock.forecastIds.includes(Number(report.ForecastID)) || batch?.id === Number(report.ForecastID));
  } else if (payload.method === "DeleteForecastReport") {
    if (batchKey && batch?.id === Number(payload.param)) await chrome.storage.local.set({ [batchKey]: { id: batch.id, deleted: true } });
    lock.forecastIds = lock.forecastIds.filter(id => id !== Number(payload.param));
    lock.expiresAt = Date.now() + FORECAST_LOCK_TTL;
    await chrome.storage.local.set({ directForecastLock: lock });
  }
  return data;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!pageRequest(sender)) return false;
  (async () => {
    if (message.action === "STATUS") {
      const config = await settings();
      const limits = forecastSettings(config);
      return { version: chrome.runtime.getManifest().version, wordstatDailyLimit: wordstatDailyLimit(config.wordstatDailyLimit), forecastSafety: true, forecastBatchRecovery: true, forecastHourlyLimit: limits.hourly, forecastDailyLimit: limits.daily, forecastAutoResume: limits.autoResume, "API-ключ Yandex Cloud": Boolean(config.cloudApiKey), "ID каталога": Boolean(config.folderId), "OAuth-токен Директа": Boolean(config.directOAuthToken) };
    }
    if (message.action === "OPEN_OPTIONS") { await chrome.runtime.openOptionsPage(); return true; }
    if (message.action === "DIRECT_FORECAST_BEGIN") return beginForecast();
    if (message.action === "DIRECT_FORECAST_TOUCH") { await forecastLock(message.payload?.sessionId); return true; }
    if (message.action === "DIRECT_FORECAST_END") return endForecast(message.payload?.sessionId);
    if (message.action === "WORDSTAT_TOP") return wordstat(message.payload || {});
    if (message.action === "WORDSTAT_REGIONS") return wordstatRegions();
    if (message.action === "DIRECT_REGIONS") return directRegions();
    if (message.action === "DIRECT_CALL") return direct(message.payload || {});
    throw new Error("Неизвестное действие");
  })().then(data => sendResponse({ ok: true, data })).catch(error => sendResponse({ ok: false, error: error.message, code: error.code, retryAfter: error.retryAfter }));
  return true;
});
